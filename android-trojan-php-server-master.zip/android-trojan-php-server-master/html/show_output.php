<?php
echo(file_get_contents("output.txt"));
?>
