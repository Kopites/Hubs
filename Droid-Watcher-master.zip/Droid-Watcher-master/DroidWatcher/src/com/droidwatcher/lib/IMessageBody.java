package com.droidwatcher.lib;

import org.json.JSONObject;

public interface IMessageBody {
	public JSONObject getJSONObject();
}
